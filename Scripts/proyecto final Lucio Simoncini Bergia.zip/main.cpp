#include<iostream>
#include "Administrar.h"
using namespace std;

int main()
{
    Administrar adm;
    adm.menu();
    return 0;
}

//g++ main.cpp Administrar.cpp Noticia.cpp Comentario.cpp Autor.cpp Usuario.cpp Persona.cpp -o programa